package co.com.choucair.certification.proyectob.userinterface;

import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;

@DefaultUrl("http://automationpractice.com/index.php")
public class AutomationPractice extends PageObject {
}
