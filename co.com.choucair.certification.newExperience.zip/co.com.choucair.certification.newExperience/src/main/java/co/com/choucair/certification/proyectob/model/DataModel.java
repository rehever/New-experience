package co.com.choucair.certification.proyectob.model;

public class DataModel {
    public String getStrAnswer() {
        return strAnswer;
    }

    public void setStrAnswer(String strAnswer) {
        this.strAnswer = strAnswer;
    }

    private String strAnswer;

    public String getStrAnswer2() {
        return strAnswer2;
    }

    public void setStrAnswer2(String strAnswer2) {
        this.strAnswer2 = strAnswer2;
    }

    private String strAnswer2;

    public String getStrName() {
        return strName;
    }

    public void setStrName(String strName) {
        this.strName = strName;
    }

    public String getStrLastName() {
        return strLastName;
    }

    public void setStrLastName(String strLastName) {
        this.strLastName = strLastName;
    }

    public String getStrPassword() {
        return strPassword;
    }

    public void setStrPassword(String strPassword) {
        this.strPassword = strPassword;
    }

    public String getStrAddress() {
        return strAddress;
    }

    public void setStrAddress(String strAddress) {
        this.strAddress = strAddress;
    }

    public String getStrCity() {
        return strCity;
    }

    public void setStrCity(String strCity) {
        this.strCity = strCity;
    }

    public String getStrState() {
        return strState;
    }

    public void setStrState(String strState) {
        this.strState = strState;
    }

    public String getStrZIP() {
        return strZIP;
    }

    public void setStrZIP(String strZIP) {
        this.strZIP = strZIP;
    }

    public String getStrPhone() {
        return strPhone;
    }

    public void setStrPhone(String strPhone) {
        this.strPhone = strPhone;
    }

    private String strName;
    private String strLastName;
    private String strPassword;
    private String strAddress;
    private String strCity;
    private String strState;
    private String strZIP;
    private String strPhone;


}
